﻿namespace Subject_Enlistment
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TableLayoutPanel tableLayoutPanel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            box_a5 = new Label();
            box5 = new Label();
            box_a4 = new Label();
            box4 = new Label();
            box_a3 = new Label();
            box3 = new Label();
            box_a2 = new Label();
            box2 = new Label();
            box_a1 = new Label();
            box1 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label7 = new Label();
            label8 = new Label();
            label10 = new Label();
            label11 = new Label();
            label13 = new Label();
            label14 = new Label();
            label16 = new Label();
            label17 = new Label();
            label19 = new Label();
            label20 = new Label();
            label22 = new Label();
            label23 = new Label();
            label25 = new Label();
            label26 = new Label();
            label28 = new Label();
            label29 = new Label();
            label31 = new Label();
            label32 = new Label();
            label34 = new Label();
            label35 = new Label();
            label36 = new Label();
            label37 = new Label();
            label38 = new Label();
            label42 = new Label();
            label39 = new Label();
            label40 = new Label();
            label41 = new Label();
            label43 = new Label();
            label44 = new Label();
            label45 = new Label();
            label46 = new Label();
            label47 = new Label();
            label48 = new Label();
            label49 = new Label();
            label50 = new Label();
            label51 = new Label();
            label52 = new Label();
            label53 = new Label();
            label54 = new Label();
            label55 = new Label();
            label56 = new Label();
            splitter1 = new Splitter();
            misc17 = new Label();
            misc15 = new Label();
            misc14 = new Label();
            misc13 = new Label();
            misc12 = new Label();
            misc11 = new Label();
            misc10 = new Label();
            misc9 = new Label();
            misc8 = new Label();
            misc7 = new Label();
            misc6 = new Label();
            misc5 = new Label();
            misc4 = new Label();
            misc3 = new Label();
            misc2 = new Label();
            misc1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            comProgLab = new TextBox();
            comProgLec = new TextBox();
            oopLabInput = new TextBox();
            oopLecInput = new TextBox();
            appDevLabInput = new TextBox();
            theoInput = new TextBox();
            peInput = new TextBox();
            utsInput = new TextBox();
            computingTwoInput = new TextBox();
            appDevLecInput = new TextBox();
            enlistButton = new Button();
            label2 = new Label();
            label6 = new Label();
            label9 = new Label();
            pictureBox14 = new PictureBox();
            totalTF = new Label();
            miscFee = new Label();
            label000 = new Label();
            label12 = new Label();
            feeAssessment = new Label();
            DP = new Label();
            termBox = new ComboBox();
            misc16 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox15 = new PictureBox();
            accountCredited1 = new TextBox();
            accountCredited2 = new TextBox();
            textBox3 = new TextBox();
            tuitionFeeLec = new TextBox();
            tuitionFeeLab = new TextBox();
            laboratoryFee = new TextBox();
            studentStatus = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.None;
            tableLayoutPanel1.AutoSize = true;
            tableLayoutPanel1.BackColor = SystemColors.ButtonHighlight;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(box_a5, 1, 4);
            tableLayoutPanel1.Controls.Add(box5, 0, 4);
            tableLayoutPanel1.Controls.Add(box_a4, 1, 3);
            tableLayoutPanel1.Controls.Add(box4, 0, 3);
            tableLayoutPanel1.Controls.Add(box_a3, 1, 2);
            tableLayoutPanel1.Controls.Add(box3, 0, 2);
            tableLayoutPanel1.Controls.Add(box_a2, 1, 1);
            tableLayoutPanel1.Controls.Add(box2, 0, 1);
            tableLayoutPanel1.Controls.Add(box_a1, 1, 0);
            tableLayoutPanel1.Controls.Add(box1, 0, 0);
            tableLayoutPanel1.Location = new Point(1069, 572);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.Size = new Size(417, 211);
            tableLayoutPanel1.TabIndex = 135;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // box_a5
            // 
            box_a5.AutoSize = true;
            box_a5.Location = new Point(212, 169);
            box_a5.Name = "box_a5";
            box_a5.Size = new Size(0, 19);
            box_a5.TabIndex = 9;
            // 
            // box5
            // 
            box5.AutoSize = true;
            box5.Location = new Point(4, 169);
            box5.Name = "box5";
            box5.Size = new Size(0, 19);
            box5.TabIndex = 8;
            // 
            // box_a4
            // 
            box_a4.AutoSize = true;
            box_a4.Location = new Point(212, 127);
            box_a4.Name = "box_a4";
            box_a4.Size = new Size(0, 19);
            box_a4.TabIndex = 7;
            // 
            // box4
            // 
            box4.AutoSize = true;
            box4.Location = new Point(4, 127);
            box4.Name = "box4";
            box4.Size = new Size(0, 19);
            box4.TabIndex = 6;
            // 
            // box_a3
            // 
            box_a3.AutoSize = true;
            box_a3.Location = new Point(212, 85);
            box_a3.Name = "box_a3";
            box_a3.Size = new Size(0, 19);
            box_a3.TabIndex = 5;
            // 
            // box3
            // 
            box3.AutoSize = true;
            box3.Location = new Point(4, 85);
            box3.Name = "box3";
            box3.Size = new Size(0, 19);
            box3.TabIndex = 4;
            // 
            // box_a2
            // 
            box_a2.AutoSize = true;
            box_a2.Location = new Point(212, 43);
            box_a2.Name = "box_a2";
            box_a2.Size = new Size(0, 19);
            box_a2.TabIndex = 3;
            // 
            // box2
            // 
            box2.AutoSize = true;
            box2.Location = new Point(4, 43);
            box2.Name = "box2";
            box2.Size = new Size(0, 19);
            box2.TabIndex = 2;
            // 
            // box_a1
            // 
            box_a1.AutoSize = true;
            box_a1.Location = new Point(212, 1);
            box_a1.Name = "box_a1";
            box_a1.Size = new Size(0, 19);
            box_a1.TabIndex = 1;
            // 
            // box1
            // 
            box1.AutoSize = true;
            box1.Location = new Point(4, 1);
            box1.Name = "box1";
            box1.Size = new Size(0, 19);
            box1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(0, 0, 192);
            label1.Location = new Point(39, 134);
            label1.Name = "label1";
            label1.Size = new Size(219, 30);
            label1.TabIndex = 0;
            label1.Text = "ENROLLED SUBJECTS";
            label1.Click += label1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.LightGray;
            label3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(46, 210);
            label3.Name = "label3";
            label3.Size = new Size(58, 20);
            label3.TabIndex = 3;
            label3.Text = "Section";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.LightGray;
            label4.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(127, 210);
            label4.Name = "label4";
            label4.Size = new Size(58, 20);
            label4.TabIndex = 4;
            label4.Text = "Subject";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.LightGray;
            label5.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(534, 210);
            label5.Name = "label5";
            label5.Size = new Size(42, 20);
            label5.TabIndex = 5;
            label5.Text = "Units";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.LightGray;
            label7.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(127, 253);
            label7.Name = "label7";
            label7.Size = new Size(292, 25);
            label7.TabIndex = 8;
            label7.Text = "COMPUTER PROGRAMMING 2 LAB";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.LightGray;
            label8.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(46, 253);
            label8.Name = "label8";
            label8.Size = new Size(62, 25);
            label8.TabIndex = 7;
            label8.Text = "60017";
            label8.Click += label8_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.LightGray;
            label10.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(127, 304);
            label10.Name = "label10";
            label10.Size = new Size(289, 25);
            label10.TabIndex = 12;
            label10.Text = "COMPUTER PROGRAMMING 2 LEC";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.LightGray;
            label11.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(46, 304);
            label11.Name = "label11";
            label11.Size = new Size(62, 25);
            label11.TabIndex = 11;
            label11.Text = "60018";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.LightGray;
            label13.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(127, 355);
            label13.Name = "label13";
            label13.Size = new Size(332, 25);
            label13.TabIndex = 16;
            label13.Text = "OBJECT ORIENTED PROGRAMMING LAB";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.LightGray;
            label14.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(46, 355);
            label14.Name = "label14";
            label14.Size = new Size(62, 25);
            label14.TabIndex = 15;
            label14.Text = "07012";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.LightGray;
            label16.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(127, 406);
            label16.Name = "label16";
            label16.Size = new Size(329, 25);
            label16.TabIndex = 20;
            label16.Text = "OBJECT ORIENTED PROGRAMMING LEC";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.LightGray;
            label17.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label17.Location = new Point(46, 406);
            label17.Name = "label17";
            label17.Size = new Size(62, 25);
            label17.TabIndex = 19;
            label17.Text = "07013";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.LightGray;
            label19.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label19.Location = new Point(127, 457);
            label19.Name = "label19";
            label19.Size = new Size(395, 25);
            label19.TabIndex = 24;
            label19.Text = "APPLICATIONS DEVT AND EMERGING TECH LAB";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.LightGray;
            label20.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label20.Location = new Point(46, 457);
            label20.Name = "label20";
            label20.Size = new Size(62, 25);
            label20.TabIndex = 23;
            label20.Text = "11980";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.BackColor = Color.LightGray;
            label22.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label22.Location = new Point(127, 508);
            label22.Name = "label22";
            label22.Size = new Size(392, 25);
            label22.TabIndex = 28;
            label22.Text = "APPLICATIONS DEVT AND EMERGING TECH LEC";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.BackColor = Color.LightGray;
            label23.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label23.Location = new Point(46, 508);
            label23.Name = "label23";
            label23.Size = new Size(62, 25);
            label23.TabIndex = 27;
            label23.Text = "11981";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.BackColor = Color.LightGray;
            label25.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label25.Location = new Point(127, 559);
            label25.Name = "label25";
            label25.Size = new Size(129, 25);
            label25.TabIndex = 32;
            label25.Text = "COMPUTING 2";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.BackColor = Color.LightGray;
            label26.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label26.Location = new Point(46, 559);
            label26.Name = "label26";
            label26.Size = new Size(62, 25);
            label26.TabIndex = 31;
            label26.Text = "34432";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.BackColor = Color.LightGray;
            label28.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label28.Location = new Point(127, 610);
            label28.Name = "label28";
            label28.Size = new Size(233, 25);
            label28.TabIndex = 36;
            label28.Text = "UNDERSTANDING THE SELF";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.BackColor = Color.LightGray;
            label29.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label29.Location = new Point(46, 610);
            label29.Name = "label29";
            label29.Size = new Size(62, 25);
            label29.TabIndex = 35;
            label29.Text = "65312";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.BackColor = Color.LightGray;
            label31.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label31.Location = new Point(127, 661);
            label31.Name = "label31";
            label31.Size = new Size(305, 25);
            label31.TabIndex = 40;
            label31.Text = "PATHFIT 2: EXERCISE BASED FITNESS";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.BackColor = Color.LightGray;
            label32.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label32.Location = new Point(46, 661);
            label32.Name = "label32";
            label32.Size = new Size(62, 25);
            label32.TabIndex = 39;
            label32.Text = "90016";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.BackColor = Color.LightGray;
            label34.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label34.Location = new Point(127, 712);
            label34.Name = "label34";
            label34.Size = new Size(115, 25);
            label34.TabIndex = 44;
            label34.Text = "THEOLOGY 2";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.BackColor = Color.LightGray;
            label35.Font = new Font("Segoe UI", 13.5F, FontStyle.Regular, GraphicsUnit.Point);
            label35.Location = new Point(46, 712);
            label35.Name = "label35";
            label35.Size = new Size(62, 25);
            label35.TabIndex = 43;
            label35.Text = "09001";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.BackColor = SystemColors.ButtonHighlight;
            label36.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            label36.ForeColor = Color.FromArgb(0, 0, 192);
            label36.Location = new Point(626, 144);
            label36.Name = "label36";
            label36.Size = new Size(201, 30);
            label36.TabIndex = 46;
            label36.Text = "Assessment of Fees";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.BackColor = SystemColors.ButtonHighlight;
            label37.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label37.Location = new Point(629, 183);
            label37.Name = "label37";
            label37.Size = new Size(191, 19);
            label37.TabIndex = 47;
            label37.Text = "TUITION FEE (LEC SUBJECT/S)\t";
            label37.Click += label37_Click;
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.BackColor = SystemColors.ButtonHighlight;
            label38.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label38.Location = new Point(629, 206);
            label38.Name = "label38";
            label38.Size = new Size(192, 19);
            label38.TabIndex = 48;
            label38.Text = "TUITION FEE (LAB SUBJECT/S)\t";
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.BackColor = SystemColors.ButtonHighlight;
            label42.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label42.Location = new Point(629, 228);
            label42.Name = "label42";
            label42.Size = new Size(115, 19);
            label42.TabIndex = 52;
            label42.Text = "AdU CHRONICLE\t";
            label42.Click += label42_Click;
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.BackColor = SystemColors.ButtonHighlight;
            label39.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label39.Location = new Point(629, 251);
            label39.Name = "label39";
            label39.Size = new Size(68, 19);
            label39.TabIndex = 53;
            label39.Text = "ATHLETIC";
            label39.Click += label39_Click;
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.BackColor = SystemColors.ButtonHighlight;
            label40.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label40.Location = new Point(629, 275);
            label40.Name = "label40";
            label40.Size = new Size(161, 19);
            label40.TabIndex = 54;
            label40.Text = "AUDIO-VISUAL LIBRARY\t";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.BackColor = SystemColors.ButtonHighlight;
            label41.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label41.Location = new Point(629, 297);
            label41.Name = "label41";
            label41.Size = new Size(45, 19);
            label41.TabIndex = 55;
            label41.Text = "AUSG";
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.BackColor = SystemColors.ButtonHighlight;
            label43.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label43.Location = new Point(629, 320);
            label43.Name = "label43";
            label43.Size = new Size(100, 19);
            label43.TabIndex = 56;
            label43.Text = "CULTURAL FEE\t";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.BackColor = SystemColors.ButtonHighlight;
            label44.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label44.Location = new Point(629, 343);
            label44.Name = "label44";
            label44.Size = new Size(241, 19);
            label44.TabIndex = 57;
            label44.Text = "ENERGY COST, AIRCON CLASSROOM";
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.BackColor = SystemColors.ButtonHighlight;
            label45.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label45.Location = new Point(629, 366);
            label45.Name = "label45";
            label45.Size = new Size(78, 19);
            label45.TabIndex = 58;
            label45.Text = "GUIDANCE\t";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.BackColor = SystemColors.ButtonHighlight;
            label46.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label46.Location = new Point(629, 390);
            label46.Name = "label46";
            label46.Size = new Size(108, 19);
            label46.TabIndex = 59;
            label46.Text = "INSURANCE FEE";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.BackColor = SystemColors.ButtonHighlight;
            label47.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label47.Location = new Point(629, 414);
            label47.Name = "label47";
            label47.Size = new Size(165, 19);
            label47.TabIndex = 60;
            label47.Text = "LABORATORY USAGE FEE";
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.BackColor = SystemColors.ButtonHighlight;
            label48.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label48.Location = new Point(629, 438);
            label48.Name = "label48";
            label48.Size = new Size(226, 19);
            label48.TabIndex = 61;
            label48.Text = "LEARNING MANAGEMENT SYSTEM";
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.BackColor = SystemColors.ButtonHighlight;
            label49.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label49.Location = new Point(629, 462);
            label49.Name = "label49";
            label49.Size = new Size(86, 19);
            label49.TabIndex = 62;
            label49.Text = "LIBRARY FEE";
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.BackColor = SystemColors.ButtonHighlight;
            label50.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label50.Location = new Point(629, 485);
            label50.Name = "label50";
            label50.Size = new Size(154, 19);
            label50.TabIndex = 63;
            label50.Text = "MEDICAL AND DENTAL";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.BackColor = SystemColors.ButtonHighlight;
            label51.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label51.Location = new Point(629, 507);
            label51.Name = "label51";
            label51.Size = new Size(100, 19);
            label51.TabIndex = 64;
            label51.Text = "REGISTRATION";
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.BackColor = SystemColors.ButtonHighlight;
            label52.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label52.Location = new Point(629, 529);
            label52.Name = "label52";
            label52.Size = new Size(67, 19);
            label52.TabIndex = 65;
            label52.Text = "ROTC FEE";
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.BackColor = SystemColors.ButtonHighlight;
            label53.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label53.Location = new Point(629, 551);
            label53.Name = "label53";
            label53.Size = new Size(35, 19);
            label53.TabIndex = 66;
            label53.Text = "RSO";
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.BackColor = SystemColors.ButtonHighlight;
            label54.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label54.Location = new Point(629, 572);
            label54.Name = "label54";
            label54.Size = new Size(163, 19);
            label54.TabIndex = 67;
            label54.Text = "STUDENT ACTIVITIES FEE";
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.BackColor = SystemColors.ButtonHighlight;
            label55.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label55.Location = new Point(629, 594);
            label55.Name = "label55";
            label55.Size = new Size(183, 19);
            label55.TabIndex = 68;
            label55.Text = "STUDENT NURTURANCE FEE";
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.BackColor = SystemColors.ButtonHighlight;
            label56.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label56.Location = new Point(629, 616);
            label56.Name = "label56";
            label56.Size = new Size(87, 19);
            label56.TabIndex = 69;
            label56.Text = "TEST PAPERS";
            // 
            // splitter1
            // 
            splitter1.Location = new Point(0, 0);
            splitter1.Name = "splitter1";
            splitter1.Size = new Size(3, 804);
            splitter1.TabIndex = 70;
            splitter1.TabStop = false;
            // 
            // misc17
            // 
            misc17.AutoSize = true;
            misc17.BackColor = SystemColors.ButtonHighlight;
            misc17.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc17.Location = new Point(915, 616);
            misc17.Name = "misc17";
            misc17.Size = new Size(52, 19);
            misc17.TabIndex = 90;
            misc17.Text = "158.00";
            misc17.TextAlign = ContentAlignment.TopRight;
            // 
            // misc15
            // 
            misc15.AutoSize = true;
            misc15.BackColor = SystemColors.ButtonHighlight;
            misc15.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc15.Location = new Point(915, 572);
            misc15.Name = "misc15";
            misc15.Size = new Size(52, 19);
            misc15.TabIndex = 88;
            misc15.Text = "275.00";
            misc15.TextAlign = ContentAlignment.TopRight;
            // 
            // misc14
            // 
            misc14.AutoSize = true;
            misc14.BackColor = SystemColors.ButtonHighlight;
            misc14.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc14.Location = new Point(923, 551);
            misc14.Name = "misc14";
            misc14.Size = new Size(44, 19);
            misc14.TabIndex = 87;
            misc14.Text = "50.00";
            misc14.TextAlign = ContentAlignment.TopRight;
            // 
            // misc13
            // 
            misc13.AutoSize = true;
            misc13.BackColor = SystemColors.ButtonHighlight;
            misc13.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc13.Location = new Point(904, 530);
            misc13.Name = "misc13";
            misc13.Size = new Size(63, 19);
            misc13.TabIndex = 86;
            misc13.Text = "2,283.00";
            misc13.TextAlign = ContentAlignment.TopRight;
            // 
            // misc12
            // 
            misc12.AutoSize = true;
            misc12.BackColor = SystemColors.ButtonHighlight;
            misc12.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc12.Location = new Point(915, 507);
            misc12.Name = "misc12";
            misc12.Size = new Size(52, 19);
            misc12.TabIndex = 85;
            misc12.Text = "237.00";
            misc12.TextAlign = ContentAlignment.TopRight;
            // 
            // misc11
            // 
            misc11.AutoSize = true;
            misc11.BackColor = SystemColors.ButtonHighlight;
            misc11.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc11.Location = new Point(915, 485);
            misc11.Name = "misc11";
            misc11.Size = new Size(52, 19);
            misc11.TabIndex = 84;
            misc11.Text = "525.00";
            misc11.TextAlign = ContentAlignment.TopRight;
            // 
            // misc10
            // 
            misc10.AutoSize = true;
            misc10.BackColor = SystemColors.ButtonHighlight;
            misc10.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc10.Location = new Point(904, 462);
            misc10.Name = "misc10";
            misc10.Size = new Size(63, 19);
            misc10.TabIndex = 83;
            misc10.Text = "1,594.00";
            misc10.TextAlign = ContentAlignment.TopRight;
            // 
            // misc9
            // 
            misc9.AutoSize = true;
            misc9.BackColor = SystemColors.ButtonHighlight;
            misc9.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc9.Location = new Point(915, 438);
            misc9.Name = "misc9";
            misc9.Size = new Size(52, 19);
            misc9.TabIndex = 82;
            misc9.Text = "788.00";
            misc9.TextAlign = ContentAlignment.TopRight;
            // 
            // misc8
            // 
            misc8.AutoSize = true;
            misc8.BackColor = SystemColors.ButtonHighlight;
            misc8.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc8.Location = new Point(923, 390);
            misc8.Name = "misc8";
            misc8.Size = new Size(44, 19);
            misc8.TabIndex = 80;
            misc8.Text = "68.00";
            misc8.TextAlign = ContentAlignment.TopRight;
            // 
            // misc7
            // 
            misc7.AutoSize = true;
            misc7.BackColor = SystemColors.ButtonHighlight;
            misc7.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc7.Location = new Point(915, 365);
            misc7.Name = "misc7";
            misc7.Size = new Size(52, 19);
            misc7.TabIndex = 79;
            misc7.Text = "402.00";
            misc7.TextAlign = ContentAlignment.TopRight;
            // 
            // misc6
            // 
            misc6.AutoSize = true;
            misc6.BackColor = SystemColors.ButtonHighlight;
            misc6.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc6.Location = new Point(904, 342);
            misc6.Name = "misc6";
            misc6.Size = new Size(63, 19);
            misc6.TabIndex = 78;
            misc6.Text = "3,591.00";
            misc6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // misc5
            // 
            misc5.AutoSize = true;
            misc5.BackColor = SystemColors.ButtonHighlight;
            misc5.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc5.Location = new Point(915, 320);
            misc5.Name = "misc5";
            misc5.Size = new Size(52, 19);
            misc5.TabIndex = 77;
            misc5.Text = "450.00";
            misc5.TextAlign = ContentAlignment.TopRight;
            // 
            // misc4
            // 
            misc4.AutoSize = true;
            misc4.BackColor = SystemColors.ButtonHighlight;
            misc4.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc4.Location = new Point(923, 297);
            misc4.Name = "misc4";
            misc4.Size = new Size(44, 19);
            misc4.TabIndex = 76;
            misc4.Text = "50.00";
            misc4.TextAlign = ContentAlignment.TopRight;
            // 
            // misc3
            // 
            misc3.AutoSize = true;
            misc3.BackColor = SystemColors.ButtonHighlight;
            misc3.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc3.Location = new Point(923, 275);
            misc3.Name = "misc3";
            misc3.Size = new Size(44, 19);
            misc3.TabIndex = 75;
            misc3.Text = "83.00";
            misc3.TextAlign = ContentAlignment.TopRight;
            // 
            // misc2
            // 
            misc2.AutoSize = true;
            misc2.BackColor = SystemColors.ButtonHighlight;
            misc2.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc2.Location = new Point(915, 251);
            misc2.Name = "misc2";
            misc2.Size = new Size(52, 19);
            misc2.TabIndex = 74;
            misc2.Text = "927.00";
            misc2.TextAlign = ContentAlignment.TopRight;
            // 
            // misc1
            // 
            misc1.AutoSize = true;
            misc1.BackColor = SystemColors.ButtonHighlight;
            misc1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc1.Location = new Point(923, 228);
            misc1.Name = "misc1";
            misc1.RightToLeft = RightToLeft.Yes;
            misc1.Size = new Size(44, 19);
            misc1.TabIndex = 73;
            misc1.Text = "66.00";
            misc1.TextAlign = ContentAlignment.MiddleRight;
            misc1.Click += label74_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Black;
            pictureBox1.Location = new Point(624, 644);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(345, 10);
            pictureBox1.TabIndex = 91;
            pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.LightGray;
            pictureBox3.Location = new Point(28, 206);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(551, 31);
            pictureBox3.TabIndex = 101;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.LightGray;
            pictureBox4.Location = new Point(28, 245);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(551, 39);
            pictureBox4.TabIndex = 102;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.LightGray;
            pictureBox5.Location = new Point(28, 296);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(551, 39);
            pictureBox5.TabIndex = 103;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.LightGray;
            pictureBox6.Location = new Point(28, 347);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(551, 39);
            pictureBox6.TabIndex = 104;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.LightGray;
            pictureBox7.Location = new Point(28, 398);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(551, 39);
            pictureBox7.TabIndex = 105;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.LightGray;
            pictureBox8.Location = new Point(28, 449);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(551, 39);
            pictureBox8.TabIndex = 106;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.LightGray;
            pictureBox9.Location = new Point(28, 500);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(551, 39);
            pictureBox9.TabIndex = 107;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.LightGray;
            pictureBox10.Location = new Point(28, 551);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(551, 39);
            pictureBox10.TabIndex = 108;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.LightGray;
            pictureBox11.Location = new Point(28, 602);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(551, 39);
            pictureBox11.TabIndex = 109;
            pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.LightGray;
            pictureBox12.Location = new Point(28, 653);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(551, 39);
            pictureBox12.TabIndex = 110;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.LightGray;
            pictureBox13.Location = new Point(28, 704);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(551, 39);
            pictureBox13.TabIndex = 111;
            pictureBox13.TabStop = false;
            // 
            // comProgLab
            // 
            comProgLab.Location = new Point(534, 253);
            comProgLab.Name = "comProgLab";
            comProgLab.Size = new Size(33, 25);
            comProgLab.TabIndex = 112;
            comProgLab.TextChanged += comProgLab_TextChanged;
            // 
            // comProgLec
            // 
            comProgLec.Location = new Point(534, 304);
            comProgLec.Name = "comProgLec";
            comProgLec.Size = new Size(33, 25);
            comProgLec.TabIndex = 113;
            comProgLec.TextChanged += comProgLec_TextChanged;
            // 
            // oopLabInput
            // 
            oopLabInput.Location = new Point(534, 355);
            oopLabInput.Name = "oopLabInput";
            oopLabInput.Size = new Size(33, 25);
            oopLabInput.TabIndex = 114;
            oopLabInput.TextChanged += oopLab_TextChanged;
            // 
            // oopLecInput
            // 
            oopLecInput.Location = new Point(534, 406);
            oopLecInput.Name = "oopLecInput";
            oopLecInput.Size = new Size(33, 25);
            oopLecInput.TabIndex = 115;
            oopLecInput.TextChanged += oopLec_TextChanged;
            // 
            // appDevLabInput
            // 
            appDevLabInput.Location = new Point(534, 457);
            appDevLabInput.Name = "appDevLabInput";
            appDevLabInput.Size = new Size(33, 25);
            appDevLabInput.TabIndex = 116;
            appDevLabInput.TextChanged += appDevLab_TextChanged;
            // 
            // theoInput
            // 
            theoInput.Location = new Point(534, 712);
            theoInput.Name = "theoInput";
            theoInput.Size = new Size(33, 25);
            theoInput.TabIndex = 121;
            theoInput.TextChanged += theologyTwo_TextChanged;
            // 
            // peInput
            // 
            peInput.Location = new Point(534, 661);
            peInput.Name = "peInput";
            peInput.Size = new Size(33, 25);
            peInput.TabIndex = 120;
            peInput.TextChanged += pathfitTwo_TextChanged;
            // 
            // utsInput
            // 
            utsInput.Location = new Point(534, 610);
            utsInput.Name = "utsInput";
            utsInput.Size = new Size(33, 25);
            utsInput.TabIndex = 119;
            utsInput.TextChanged += understandingTheSelf_TextChanged;
            // 
            // computingTwoInput
            // 
            computingTwoInput.Location = new Point(534, 559);
            computingTwoInput.Name = "computingTwoInput";
            computingTwoInput.Size = new Size(33, 25);
            computingTwoInput.TabIndex = 118;
            computingTwoInput.TextChanged += computingTwo_TextChanged;
            // 
            // appDevLecInput
            // 
            appDevLecInput.Location = new Point(534, 508);
            appDevLecInput.Name = "appDevLecInput";
            appDevLecInput.Size = new Size(33, 25);
            appDevLecInput.TabIndex = 117;
            appDevLecInput.TextChanged += appDevLec_TextChanged;
            // 
            // enlistButton
            // 
            enlistButton.Location = new Point(478, 751);
            enlistButton.Name = "enlistButton";
            enlistButton.Size = new Size(101, 27);
            enlistButton.TabIndex = 122;
            enlistButton.Text = "ENLIST";
            enlistButton.UseVisualStyleBackColor = true;
            enlistButton.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(0, 0, 192);
            label2.Location = new Point(1069, 144);
            label2.Name = "label2";
            label2.Size = new Size(109, 30);
            label2.TabIndex = 123;
            label2.Text = "Total Fees";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(1069, 183);
            label6.Name = "label6";
            label6.Size = new Size(133, 21);
            label6.TabIndex = 124;
            label6.Text = "Total Tuition Fee : ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.ButtonHighlight;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(1069, 203);
            label9.Name = "label9";
            label9.Size = new Size(143, 21);
            label9.TabIndex = 125;
            label9.Text = "Miscellaneous Fee :";
            // 
            // pictureBox14
            // 
            pictureBox14.BackColor = Color.Black;
            pictureBox14.Location = new Point(1069, 230);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(345, 10);
            pictureBox14.TabIndex = 126;
            pictureBox14.TabStop = false;
            // 
            // totalTF
            // 
            totalTF.AutoSize = true;
            totalTF.BackColor = SystemColors.ButtonHighlight;
            totalTF.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            totalTF.ImageAlign = ContentAlignment.MiddleRight;
            totalTF.Location = new Point(1302, 186);
            totalTF.Name = "totalTF";
            totalTF.RightToLeft = RightToLeft.No;
            totalTF.Size = new Size(36, 19);
            totalTF.TabIndex = 127;
            totalTF.Text = "0.00";
            totalTF.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // miscFee
            // 
            miscFee.AutoSize = true;
            miscFee.BackColor = SystemColors.ButtonHighlight;
            miscFee.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            miscFee.ImageAlign = ContentAlignment.MiddleRight;
            miscFee.Location = new Point(1302, 205);
            miscFee.Name = "miscFee";
            miscFee.RightToLeft = RightToLeft.No;
            miscFee.Size = new Size(36, 19);
            miscFee.TabIndex = 128;
            miscFee.Text = "0.00";
            miscFee.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label000
            // 
            label000.AutoSize = true;
            label000.BackColor = SystemColors.ButtonHighlight;
            label000.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label000.Location = new Point(1069, 251);
            label000.Name = "label000";
            label000.Size = new Size(152, 21);
            label000.TabIndex = 129;
            label000.Text = "Assessment of Fees :";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.ButtonHighlight;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(1069, 272);
            label12.Name = "label12";
            label12.Size = new Size(119, 21);
            label12.TabIndex = 130;
            label12.Text = "Downpayment :";
            // 
            // feeAssessment
            // 
            feeAssessment.AutoSize = true;
            feeAssessment.BackColor = SystemColors.ButtonHighlight;
            feeAssessment.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            feeAssessment.ImageAlign = ContentAlignment.MiddleRight;
            feeAssessment.Location = new Point(1302, 253);
            feeAssessment.Name = "feeAssessment";
            feeAssessment.RightToLeft = RightToLeft.No;
            feeAssessment.Size = new Size(36, 19);
            feeAssessment.TabIndex = 131;
            feeAssessment.Text = "0.00";
            feeAssessment.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // DP
            // 
            DP.AutoSize = true;
            DP.BackColor = SystemColors.ButtonHighlight;
            DP.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            DP.ImageAlign = ContentAlignment.MiddleRight;
            DP.Location = new Point(1302, 275);
            DP.Name = "DP";
            DP.RightToLeft = RightToLeft.No;
            DP.Size = new Size(36, 19);
            DP.TabIndex = 132;
            DP.Text = "0.00";
            DP.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // termBox
            // 
            termBox.FormattingEnabled = true;
            termBox.Items.AddRange(new object[] { "Full Payment", "2 Term", "3 Term", "4 Term", "5 Term" });
            termBox.Location = new Point(1281, 545);
            termBox.Name = "termBox";
            termBox.RightToLeft = RightToLeft.No;
            termBox.Size = new Size(205, 25);
            termBox.TabIndex = 134;
            termBox.Text = "PAYMENT TERMS";
            termBox.SelectedIndexChanged += termBox_SelectedIndexChanged;
            // 
            // misc16
            // 
            misc16.AutoSize = true;
            misc16.BackColor = SystemColors.ButtonHighlight;
            misc16.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            misc16.Location = new Point(915, 594);
            misc16.Name = "misc16";
            misc16.Size = new Size(52, 19);
            misc16.TabIndex = 89;
            misc16.Text = "362.00";
            misc16.TextAlign = ContentAlignment.TopRight;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.White;
            pictureBox2.Location = new Point(12, 111);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1486, 681);
            pictureBox2.TabIndex = 136;
            pictureBox2.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.BackColor = Color.Transparent;
            pictureBox15.BackgroundImage = (Image)resources.GetObject("pictureBox15.BackgroundImage");
            pictureBox15.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox15.Location = new Point(12, 12);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(341, 91);
            pictureBox15.TabIndex = 137;
            pictureBox15.TabStop = false;
            // 
            // accountCredited1
            // 
            accountCredited1.BackColor = Color.Yellow;
            accountCredited1.BorderStyle = BorderStyle.FixedSingle;
            accountCredited1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            accountCredited1.Location = new Point(1069, 308);
            accountCredited1.Multiline = true;
            accountCredited1.Name = "accountCredited1";
            accountCredited1.ReadOnly = true;
            accountCredited1.Size = new Size(417, 63);
            accountCredited1.TabIndex = 138;
            accountCredited1.Text = "Your payment has been credited to your account. Please print your enrolled subjects and assessment from your E-Learning Account as proof of your Enrollment.";
            accountCredited1.TextAlign = HorizontalAlignment.Center;
            accountCredited1.Visible = false;
            // 
            // accountCredited2
            // 
            accountCredited2.BackColor = Color.Yellow;
            accountCredited2.BorderStyle = BorderStyle.FixedSingle;
            accountCredited2.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point);
            accountCredited2.Location = new Point(1069, 379);
            accountCredited2.Multiline = true;
            accountCredited2.Name = "accountCredited2";
            accountCredited2.ReadOnly = true;
            accountCredited2.Size = new Size(417, 147);
            accountCredited2.TabIndex = 139;
            accountCredited2.Text = resources.GetString("accountCredited2.Text");
            accountCredited2.TextAlign = HorizontalAlignment.Center;
            accountCredited2.Visible = false;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.White;
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(624, 661);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(345, 117);
            textBox3.TabIndex = 140;
            textBox3.Text = resources.GetString("textBox3.Text");
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // tuitionFeeLec
            // 
            tuitionFeeLec.BackColor = Color.White;
            tuitionFeeLec.BorderStyle = BorderStyle.None;
            tuitionFeeLec.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            tuitionFeeLec.Location = new Point(827, 180);
            tuitionFeeLec.Name = "tuitionFeeLec";
            tuitionFeeLec.ReadOnly = true;
            tuitionFeeLec.RightToLeft = RightToLeft.Yes;
            tuitionFeeLec.Size = new Size(137, 20);
            tuitionFeeLec.TabIndex = 141;
            tuitionFeeLec.Text = "0.00";
            // 
            // tuitionFeeLab
            // 
            tuitionFeeLab.BackColor = Color.White;
            tuitionFeeLab.BorderStyle = BorderStyle.None;
            tuitionFeeLab.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            tuitionFeeLab.Location = new Point(827, 205);
            tuitionFeeLab.Name = "tuitionFeeLab";
            tuitionFeeLab.ReadOnly = true;
            tuitionFeeLab.RightToLeft = RightToLeft.Yes;
            tuitionFeeLab.Size = new Size(137, 20);
            tuitionFeeLab.TabIndex = 142;
            tuitionFeeLab.Text = "0.00";
            // 
            // laboratoryFee
            // 
            laboratoryFee.BackColor = Color.White;
            laboratoryFee.BorderStyle = BorderStyle.None;
            laboratoryFee.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            laboratoryFee.Location = new Point(825, 415);
            laboratoryFee.Name = "laboratoryFee";
            laboratoryFee.ReadOnly = true;
            laboratoryFee.RightToLeft = RightToLeft.Yes;
            laboratoryFee.Size = new Size(137, 20);
            laboratoryFee.TabIndex = 143;
            laboratoryFee.Text = "0.00";
            // 
            // studentStatus
            // 
            studentStatus.BackColor = Color.White;
            studentStatus.BorderStyle = BorderStyle.None;
            studentStatus.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            studentStatus.Location = new Point(136, 175);
            studentStatus.Name = "studentStatus";
            studentStatus.ReadOnly = true;
            studentStatus.RightToLeft = RightToLeft.No;
            studentStatus.Size = new Size(344, 25);
            studentStatus.TabIndex = 144;
            studentStatus.Text = "Status: --";
            studentStatus.TextAlign = HorizontalAlignment.Center;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.RoyalBlue;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1510, 804);
            Controls.Add(studentStatus);
            Controls.Add(laboratoryFee);
            Controls.Add(tuitionFeeLab);
            Controls.Add(tuitionFeeLec);
            Controls.Add(textBox3);
            Controls.Add(accountCredited2);
            Controls.Add(accountCredited1);
            Controls.Add(pictureBox15);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(termBox);
            Controls.Add(DP);
            Controls.Add(feeAssessment);
            Controls.Add(label12);
            Controls.Add(label000);
            Controls.Add(miscFee);
            Controls.Add(totalTF);
            Controls.Add(pictureBox14);
            Controls.Add(label9);
            Controls.Add(label6);
            Controls.Add(label2);
            Controls.Add(enlistButton);
            Controls.Add(theoInput);
            Controls.Add(peInput);
            Controls.Add(utsInput);
            Controls.Add(computingTwoInput);
            Controls.Add(appDevLecInput);
            Controls.Add(appDevLabInput);
            Controls.Add(oopLecInput);
            Controls.Add(oopLabInput);
            Controls.Add(comProgLec);
            Controls.Add(comProgLab);
            Controls.Add(pictureBox1);
            Controls.Add(misc17);
            Controls.Add(misc16);
            Controls.Add(misc15);
            Controls.Add(misc14);
            Controls.Add(misc13);
            Controls.Add(misc12);
            Controls.Add(misc11);
            Controls.Add(misc10);
            Controls.Add(misc9);
            Controls.Add(misc8);
            Controls.Add(misc7);
            Controls.Add(misc6);
            Controls.Add(misc5);
            Controls.Add(misc4);
            Controls.Add(misc3);
            Controls.Add(misc2);
            Controls.Add(misc1);
            Controls.Add(splitter1);
            Controls.Add(label56);
            Controls.Add(label55);
            Controls.Add(label54);
            Controls.Add(label53);
            Controls.Add(label52);
            Controls.Add(label51);
            Controls.Add(label50);
            Controls.Add(label49);
            Controls.Add(label48);
            Controls.Add(label47);
            Controls.Add(label46);
            Controls.Add(label45);
            Controls.Add(label44);
            Controls.Add(label43);
            Controls.Add(label41);
            Controls.Add(label40);
            Controls.Add(label39);
            Controls.Add(label42);
            Controls.Add(label38);
            Controls.Add(label37);
            Controls.Add(label36);
            Controls.Add(label34);
            Controls.Add(label35);
            Controls.Add(label31);
            Controls.Add(label32);
            Controls.Add(label28);
            Controls.Add(label29);
            Controls.Add(label25);
            Controls.Add(label26);
            Controls.Add(label22);
            Controls.Add(label23);
            Controls.Add(label19);
            Controls.Add(label20);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox2);
            Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label10;
        private Label label11;
        private Label label13;
        private Label label14;
        private Label label16;
        private Label label17;
        private Label label19;
        private Label label20;
        private Label label22;
        private Label label23;
        private Label label25;
        private Label label26;
        private Label label28;
        private Label label29;
        private Label label31;
        private Label label32;
        private Label label34;
        private Label label35;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label42;
        private Label label39;
        private Label label40;
        private Label label41;
        private Label label43;
        private Label label44;
        private Label label45;
        private Label label46;
        private Label label47;
        private Label label48;
        private Label label49;
        private Label label50;
        private Label label51;
        private Label label52;
        private Label label53;
        private Label label54;
        private Label label55;
        private Label label56;
        private Splitter splitter1;
        private Label misc17;
        private Label misc15;
        private Label misc14;
        private Label misc13;
        private Label misc12;
        private Label misc11;
        private Label misc10;
        private Label misc9;
        private Label misc8;
        private Label misc7;
        private Label misc6;
        private Label misc5;
        private Label misc4;
        private Label misc3;
        private Label misc2;
        private Label misc1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private TextBox comProgLab;
        private TextBox comProgLec;
        private TextBox oopLabInput;
        private TextBox oopLecInput;
        private TextBox appDevLabInput;
        private TextBox theoInput;
        private TextBox peInput;
        private TextBox utsInput;
        private TextBox computingTwoInput;
        private TextBox appDevLecInput;
        private Button enlistButton;
        private Label label2;
        private Label label6;
        private Label label9;
        private PictureBox pictureBox14;
        private Label totalTF;
        private Label miscFee;
        private Label label000;
        private Label label12;
        private Label feeAssessment;
        private Label DP;
        private ComboBox termBox;
        private TableLayoutPanel tableLayoutPanel1;
        private Label box1;
        private Label box_a5;
        private Label box5;
        private Label box_a4;
        private Label box4;
        private Label box_a3;
        private Label box3;
        private Label box_a2;
        private Label box2;
        private Label box_a1;
        private Label misc16;
        private PictureBox pictureBox2;
        private PictureBox pictureBox15;
        private TextBox accountCredited1;
        private TextBox accountCredited2;
        private TextBox textBox3;
        private TextBox tuitionFeeLec;
        private TextBox tuitionFeeLab;
        private TextBox laboratoryFee;
        private TextBox studentStatus;
    }
}